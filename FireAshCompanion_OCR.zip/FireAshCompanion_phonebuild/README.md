# Fire Ash Companion — OCR prototype for AYN Thor

Esta versión añade:
- Captura de pantalla mediante Android MediaProjection.
- OCR local con ML Kit.
- Coincidencia tolerante a errores contra los nombres reales de TU `Data.zip` de Fire Ash.
- Ficha automática en una `Presentation` sobre una pantalla secundaria cuando la AYN Thor la expone como secondary display.
- Base de datos completa de Fire Ash incluida en `app/src/main/assets/fireash_database.json`.

## Cómo probarla sin PC
1. Sube este proyecto a un repositorio GitHub desde el navegador del móvil.
2. Ve a **Actions** → **Build Fire Ash Companion APK** → **Run workflow**.
3. Descarga el artefacto `FireAshCompanion-debug` cuando termine.
4. Instala el APK en la Thor.
5. Abre Fire Ash Companion y pulsa **Iniciar OCR**.
6. Acepta el permiso de captura de pantalla.
7. Abre JoiPlay y Fire Ash.

Nota: el soporte multi-display depende de cómo exponga Android de la Thor la segunda pantalla. Si la Presentation no aparece en la pantalla inferior, en la siguiente iteración se puede adaptar al mecanismo específico de la Thor.
