package com.fireash.companion;

import android.app.Activity;
import android.content.Intent;
import android.media.projection.MediaProjectionManager;
import android.os.Bundle;
import android.widget.*;
import android.graphics.Color;
import android.view.Gravity;

public class MainActivity extends Activity {
    private static final int REQ_CAPTURE = 9001;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(28,28,28,28);
        TextView title = new TextView(this);
        title.setText("Fire Ash Companion\nOCR + pantalla inferior");
        title.setTextSize(24); title.setGravity(Gravity.CENTER); title.setTextColor(Color.WHITE);
        root.addView(title, new LinearLayout.LayoutParams(-1, 0, 1));

        TextView info = new TextView(this);
        info.setText("1. Pulsa Iniciar OCR\n2. Acepta la captura de pantalla\n3. Abre Pokémon Fire Ash en JoiPlay\n4. La ficha aparecerá automáticamente en la pantalla inferior de la Thor.");
        info.setTextSize(16); info.setTextColor(Color.WHITE);
        root.addView(info, new LinearLayout.LayoutParams(-1, 0, 2));

        Button start = new Button(this); start.setText("Iniciar OCR");
        root.addView(start, new LinearLayout.LayoutParams(-1, 70));
        TextView status = new TextView(this); status.setText("Estado: detenido"); status.setTextColor(Color.LTGRAY);
        root.addView(status, new LinearLayout.LayoutParams(-1, 70));
        setContentView(root);

        start.setOnClickListener(v -> {
            MediaProjectionManager mpm = (MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);
            startActivityForResult(mpm.createScreenCaptureIntent(), REQ_CAPTURE);
        });
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_CAPTURE && resultCode == RESULT_OK && data != null) {
            Intent i = new Intent(this, OcrCaptureService.class);
            i.putExtra("resultCode", resultCode);
            i.putExtra("data", data);
            startForegroundService(i);
            Toast.makeText(this, "OCR iniciado. Puedes abrir JoiPlay.", Toast.LENGTH_LONG).show();
        }
    }
}
