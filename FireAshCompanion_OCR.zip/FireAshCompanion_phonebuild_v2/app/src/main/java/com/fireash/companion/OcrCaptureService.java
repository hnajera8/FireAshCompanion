package com.fireash.companion;

import android.app.*;
import android.content.*;
import android.graphics.*;
import android.hardware.display.*;
import android.media.*;
import android.media.projection.*;
import android.os.*;
import android.util.DisplayMetrics;
import android.view.*;
import android.widget.*;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import org.json.*;
import java.io.*;
import java.nio.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.*;

public class OcrCaptureService extends Service {
    static final String CHANNEL="fireash_ocr";
    MediaProjection projection; VirtualDisplay virtualDisplay; ImageReader reader;
    TextRecognizer recognizer; Handler handler; ExecutorService executor;
    JSONObject db; DexPresentation presentation; Display targetDisplay;
    String lastCandidate=""; int stable=0; long lastScan=0;

    @Override public void onCreate() {
        super.onCreate(); handler=new Handler(Looper.getMainLooper()); executor=Executors.newSingleThreadExecutor();
        recognizer=TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
        db=loadDb(); createChannel();
    }
    private JSONObject loadDb(){
        try(InputStream in=getAssets().open("fireash_database.json")){
            byte[] b=new byte[in.available()]; in.read(b); return new JSONObject(new String(b, StandardCharsets.UTF_8));
        } catch(Exception e){ return new JSONObject(); }
    }
    private void createChannel(){
        NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel(CHANNEL,"Fire Ash OCR",NotificationManager.IMPORTANCE_LOW));
    }
    private void notifyFg(){
        Notification n=new Notification.Builder(this,CHANNEL).setContentTitle("Fire Ash Companion")
          .setContentText("Detectando Pokémon en JoiPlay…").setSmallIcon(android.R.drawable.ic_menu_search).build();
        startForeground(77,n);
    }
    @Override public int onStartCommand(Intent intent,int flags,int startId){
        notifyFg();
        try{
            int rc=intent.getIntExtra("resultCode",Activity.RESULT_CANCELED);
            Intent data=intent.getParcelableExtra("data");
            MediaProjectionManager mpm=(MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);
            projection=mpm.getMediaProjection(rc,data);
            setupDisplay();
        }catch(Exception e){ stopSelf(); }
        return START_STICKY;
    }
    private void setupDisplay(){
        DisplayManager dm=(DisplayManager)getSystemService(DISPLAY_SERVICE);
        Display[] displays=dm.getDisplays();
        for(Display d:displays) if(d.getDisplayId()!=Display.DEFAULT_DISPLAY){ targetDisplay=d; break; }
        if(targetDisplay!=null){ handler.post(()->showPresentation(targetDisplay)); }

        DisplayMetrics m=new DisplayMetrics(); dm.getDisplay(Display.DEFAULT_DISPLAY).getRealMetrics(m);
        int w=m.widthPixels, h=m.heightPixels, dpi=m.densityDpi;
        reader=ImageReader.newInstance(w,h,PixelFormat.RGBA_8888,2);
        reader.setOnImageAvailableListener(r->{ Image img=null; try{img=r.acquireLatestImage(); if(img!=null){
            long now=System.currentTimeMillis(); if(now-lastScan<650) return; lastScan=now;
            Image finalImg=img; executor.execute(()->process(finalImg)); return;
        }}catch(Exception ignored){} finally{ if(img!=null) img.close(); } },handler);
        virtualDisplay=projection.createVirtualDisplay("FireAshOCR",w,h,dpi,DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,reader.getSurface(),null,handler);
    }
    private void showPresentation(Display d){
        if(presentation!=null) presentation.dismiss();
        presentation=new DexPresentation(this,d);
        presentation.show();
    }
    private void process(Image image){
        try{
            Image.Plane p=image.getPlanes()[0]; ByteBuffer buf=p.getBuffer(); int ps=p.getPixelStride(), rs=p.getRowStride();
            int w=image.getWidth(), h=image.getHeight(); int rowPad=rs-ps*w;
            Bitmap bmp=Bitmap.createBitmap(w+rowPad/ps,h,Bitmap.Config.ARGB_8888); bmp.copyPixelsFromBuffer(buf);
            // On Thor the game is normally on the upper/primary display. Ignore the lower half to reduce false matches.
            Bitmap crop=Bitmap.createBitmap(bmp,0,0,w,Math.max(1,h/2)); bmp.recycle();
            InputImage ii=InputImage.fromBitmap(crop,0);
            recognizer.process(ii).addOnSuccessListener(text->{
                String candidate=findCandidate(text.getText());
                if(candidate!=null){
                    if(candidate.equalsIgnoreCase(lastCandidate)) stable++; else {lastCandidate=candidate;stable=1;}
                    if(stable>=2) handler.post(()->updatePresentation(candidate));
                }
                crop.recycle();
            }).addOnFailureListener(e->{try{crop.recycle();}catch(Exception ignored){}});
        }catch(Exception ignored){}
    }
    private String findCandidate(String text){
        if(text==null) return null;
        String normalized=norm(text);
        try{
            JSONObject species=db.getJSONObject("species");
            String best=null; int bestScore=999;
            for(String k:species.keySet()){
                String name=species.getJSONObject(k).optString("name",""); if(name.isEmpty()) continue;
                String nn=norm(name);
                if(normalized.contains(nn)) return name;
                int d=distance(nn,normalized);
                if(d<bestScore && d<=Math.max(2,nn.length()/4)){bestScore=d;best=name;}
                for(String token:text.split("\\n")){
                    int td=distance(nn,norm(token)); if(td<bestScore && td<=Math.max(2,nn.length()/3)){bestScore=td;best=name;}
                }
            }
            return best;
        }catch(Exception e){return null;}
    }
    private String norm(String s){return s.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]","");}
    private int distance(String a,String b){
        if(a.length()==0)return b.length(); if(b.length()==0)return a.length();
        int[] prev=new int[b.length()+1], cur=new int[b.length()+1]; for(int j=0;j<=b.length();j++)prev[j]=j;
        for(int i=1;i<=a.length();i++){cur[0]=i; for(int j=1;j<=b.length();j++)cur[j]=Math.min(Math.min(cur[j-1]+1,prev[j]+1),prev[j-1]+(a.charAt(i-1)==b.charAt(j-1)?0:1)); int[] t=prev;prev=cur;cur=t;} return prev[b.length()];
    }
    private void updatePresentation(String name){ if(presentation!=null) presentation.setSpecies(name,db); }

    @Override public void onDestroy(){
        if(virtualDisplay!=null)virtualDisplay.release(); if(reader!=null)reader.close(); if(projection!=null)projection.stop();
        if(presentation!=null)presentation.dismiss(); if(recognizer!=null)recognizer.close(); if(executor!=null)executor.shutdownNow(); super.onDestroy();
    }
    @Override public android.os.IBinder onBind(Intent i){return null;}

    static class DexPresentation extends Presentation {
        LinearLayout root; TextView title,body;
        DexPresentation(Context c,Display d){super(c,d);}
        @Override protected void onCreate(Bundle b){super.onCreate(b); root=new LinearLayout(getContext());root.setOrientation(LinearLayout.VERTICAL);root.setPadding(22,18,22,18);
            title=new TextView(getContext());title.setText("Fire Ash Companion");title.setTextSize(26);title.setGravity(Gravity.CENTER);root.addView(title,new LinearLayout.LayoutParams(-1,70));
            body=new TextView(getContext());body.setTextSize(16);ScrollView s=new ScrollView(getContext());s.addView(body);root.addView(s,new LinearLayout.LayoutParams(-1,0,1));setContentView(root);}
        void setSpecies(String name,JSONObject db){try{JSONObject s=null;JSONObject sp=db.getJSONObject("species");for(String k:sp.keySet()){JSONObject x=sp.getJSONObject(k);if(x.optString("name").equalsIgnoreCase(name)){s=x;break;}}if(s==null)return;
            StringBuilder o=new StringBuilder();o.append(s.optString("name")).append("\n");o.append(join(s.optJSONArray("types")," / ")).append("\n\n");
            o.append(s.optString("category")).append("\n");o.append(s.optString("dex")).append("\n\n");
            o.append("BASE STATS\n").append(s.optJSONObject("stats")).append("\n\n");
            o.append("ABILITIES\n").append(join(s.optJSONArray("abilities"),", "));if(s.optJSONArray("hidden_abilities")!=null)o.append("\nHidden: ").append(join(s.optJSONArray("hidden_abilities"),", "));o.append("\n\n");
            o.append("MOVES BY LEVEL\n");JSONArray mv=s.optJSONArray("moves");if(mv!=null)for(int i=0;i<mv.length();i++){JSONArray a=mv.getJSONArray(i);o.append("Lv ").append(a.optInt(0)).append(" — ").append(a.optString(1)).append("\n");}
            o.append("\nHEIGHT: ").append(s.optString("height")).append("  WEIGHT: ").append(s.optString("weight"));
            title.setText(s.optString("name"));body.setText(o.toString());
        }catch(Exception ignored){}}
        String join(JSONArray a,String sep){if(a==null)return "";StringBuilder x=new StringBuilder();for(int i=0;i<a.length();i++){if(i>0)x.append(sep);x.append(a.optString(i));}return x.toString();}
    }
}
