# Fire Ash Companion OCR v2

Versión corregida para compilar desde GitHub Actions. Incluye OCR con ML Kit, base de datos de Pokémon Fire Ash y presentación en la pantalla secundaria.

## Compilación desde móvil
1. Sube este ZIP al repositorio como `FireAshCompanion_OCR_v2.zip`.
2. Edita/crea `.github/workflows/build-apk.yml` con el workflow incluido (el workflow se ejecuta desde el repo, no desde dentro del ZIP).
3. En Actions ejecuta `Build Fire Ash Companion APK`.
4. Descarga el artefacto `FireAshCompanion-APK`.
